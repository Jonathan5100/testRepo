
function removeHash () { 
    var scrollV, scrollH, loc = window.location;
    if ("pushState" in history)
        history.pushState("", document.title, loc.pathname + loc.search);
    else {
        // Prevent scrolling by storing the page's current scroll offset
        scrollV = document.body.scrollTop;
        scrollH = document.body.scrollLeft;

        loc.hash = "";

        // Restore the scroll offset, should be flicker free
        document.body.scrollTop = scrollV;
        document.body.scrollLeft = scrollH;
    }
}    

(function($){


    $(document).ready(function(){

        $('.featured').hover(function(e){
            $(this).addClass('active');

        },function(e){
            $(this).removeClass('active');
        } );


        //JS to hover closest div to center of screen 
        //$(window).on('scroll resize', _.throttle(highlightRow, 10));

        //Navigate to section
        $('body').on('click', 'a[href*="#jn"]', function(e){  
            var href = $(this).attr('href');            

            if(!s.include(href, '#jn-')){
                // only operate on jump-nav-anchors.
                return true;
            }
            
            var pound_index = href.indexOf('#');
            var pathname = href.slice(0, pound_index);


            if(pathname.length > 0){
                //make sure we're at the right pathname, if not go there first
                if(window.location.pathname != pathname){                    
                    window.location.href = href;
                    return false;
                }
            }            

            e.preventDefault();
            navigateToSection($(this));
            
            //close menu after click on floating since it gets in the way
            $main_navigation = $(this).closest('header.responsive-menu .main-navigation');
            $main_navigation.removeClass('toggled');
        })


        //onload, make sure we navigate to the proper hash if using jump navigation

        var initialJumpNav = _.once(function(){
            if(window.location.hash.length > 0){
                if(s.include(window.location.hash, '#jn-')){                    
                    $('a[href*="'+window.location.hash+'"]').first().trigger('click');
                }
            }
            removeHash();
        });

        initialJumpNav();

    
    });


    var first_navigate = false;
    var navigateToSection = function($element){
        var section = $element.attr('href');
        var pound_index = section.indexOf('#');
        section = section.slice(pound_index);
        section = s(section).replaceAll('#jn-', '').value();
        //section = s(section).ltrim('#jn-').value();
        var el = $('[id="'+section+'"]');
        var elOffset = el.offset().top;
        var elHeight = el.height();
        var windowHeight = $(window).height();
        var offset;

        if (elHeight < windowHeight) {
            offset = elOffset - ((windowHeight / 2) - (elHeight / 2) + 50);
        }
        else {
            offset = isMobile() ? elOffset - 60 : elOffset - 100;
        }
        
        $("html, body").animate({ scrollTop: offset }, 1000);

        if(!first_navigate){
            first_navigate = true;
            window.setTimeout(function(){navigateToSection($element);}, 30);
        }
        return false;        
        
    }


    var highlightRow = function(){
        var $closest_element = null;
        var closest_distance = 3000;
        $('.highlight-row').each(function(key, value){  
            var window_center = $(window).scrollTop() + $(window).height() / 2;
            var element_offset = $(this).offset().top + 150;// + $(this).height() / 2;
            var distance      = Math.abs(window_center - element_offset);
            if(distance < closest_distance && distance < $(window).height() / 2){
                closest_distance = distance;
                $closest_element = $(this);
            }
            
        });
        if(!_.isNull($closest_element)){
            $('.highlight-row').css('background-color', 'transparent');            
            $('.highlight-row').css('background-image', 'none');            
            $closest_element.css('background-color', 'rgba(178,178,170,.1)');
            $closest_element.css('background-image', 'url(\"/wp-content/themes/ultra-child/assets/image/black-linen-light.png\"');
        }
        else{
            $('.highlight-row').css('background-color', 'transparent');  
            $('.highlight-row').css('background-image', 'none');              
        }
    }

    /** detected by Pixel Size **/
    var isMobile = function(){
        console.log($(window).width());
        return $(window).width() < 600 ? true : false;    
    }


    /** mobile menu accordian clicking parent nav with sub-menu shouldn't close the mobile menu... lets override that behavior**/

    $('nav li.menu-item-has-children > a').on('click', function(e){
        e.preventDefault();
        e.stopImmediatePropagation();
        $(this).closest('li').toggleClass('up');
        return false; 
    })

})( jQuery );




    