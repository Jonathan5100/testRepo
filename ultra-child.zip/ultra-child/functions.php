<?php

////
// this function initializes the iframe elements 
////

add_shortcode('iframe', array('iframe_shortcode', 'shortcode'));
class iframe_shortcode {
    function shortcode($atts, $content=null) {
          extract(shortcode_atts(array(
               'src'      => '',
               'style'      => '',
               'scrolling'      => 'no',
               'width'      => '100%',
               'height'      => '500',
               'frameborder'      => '0',
               'marginheight'      => '0',
          ), $atts));
 
          if (empty($src)) return '<!-- Iframe: You did not enter a valid URL -->';
 
     return '<iframe src="'.$src.'" style="'.$style. '" title="" width="'.$width.'" height="'.$height.'" scrolling="'.$scrolling.'" frameborder="'.$frameborder.'" marginheight="'.$marginheight.'"></iframe>';
    }
}

////
//  Add Featured Image to Event List Widget
////

function custom_widget_featured_image() {
    global $post;



    $featured_image = tribe_event_featured_image( $post->ID, 'thumbnail' );
    
    if(empty($featured_image)){
        $featured_image ='<div class="tribe-events-event-image"><a href="https://aiche.utahclubs.org/event/test-event/">
        <div class="no-event-image"><i class="fa fa-calendar"></i>  </div>
        </a></div>';
    }

    echo $featured_image;


}

add_action( 'tribe_events_list_widget_before_the_event_title', 'custom_widget_featured_image' );


/**
* Load custom css
*/
function theme_enqueue_styles() {

	$parent_style = 'parent-style';

	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style',
		get_stylesheet_directory_uri() . '/assets/css/custom-theme.min.css',
		array( $parent_style )
		);
    wp_enqueue_style( 'child-custom-style',
        get_stylesheet_directory_uri() . '/assets/css/custom.css',
        array( $parent_style )
        );      
    wp_enqueue_style( 'material-icons',  'https://fonts.googleapis.com/icon?family=Material+Icons' );      

}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );


/**
* Load custom js
*/
function theme_enqueue_scripts() {

    wp_enqueue_script( 'child-script', get_stylesheet_directory_uri() . '/assets/js/custom.js', array(), null, true);
    wp_enqueue_script( 'underscore-script', get_stylesheet_directory_uri() . '/assets/vendor/underscore/underscore.min.js');
    wp_enqueue_script( 'underscore-string-script', get_stylesheet_directory_uri() . '/assets/vendor/underscore/underscore.string.min.js');
}

add_action( 'wp_enqueue_scripts', 'theme_enqueue_scripts' );




if ( ! function_exists( 'ultra_top_bar_text_area' ) ):
/**
 * Display the top bar text.
 */
function ultra_top_bar_text_area(){
	$phone = wp_kses_post( siteorigin_setting('text_phone') );
	$email = wp_kses_post( siteorigin_setting('text_email') );
	$facebook = wp_kses_post( siteorigin_setting('social_facebook') );
	
	// if ( siteorigin_setting('text_phone') ) {
	// 	echo '<span class="phone"><a href="tel:' . $phone . '">' . $phone . '</a></span>';
	// }

	// if ( siteorigin_setting('text_email') ) {
	// 	echo '<span class="email"><a href="mailto:' . $email . '"> </a></span>';
	// }
	if ( siteorigin_setting('text_email') ) {	
		?>
		<div class="top-bar-menu">
			<ul class="menu">
				<li></li>
				<li id="" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="mailto:<?= $email;?>"> <i class="fa fa-envelope" aria-hidden="true"></i></a></li>
			</ul>
		</div>
		<?php
	}

}
add_action( 'ultra_top_bar_text', 'ultra_top_bar_text_area' );
endif;



if(!function_exists('ultra_display_logo')):
/**
 * Display the logo.
 */
function ultra_display_logo(){
	$logo = siteorigin_setting( 'header_logo' );
	$logo = apply_filters('ultra_logo_image_id', $logo);

	if( empty($logo) ) {
		if ( function_exists( 'jetpack_the_site_logo' ) && jetpack_has_site_logo() ) {
			// We'll let Jetpack handle things
			jetpack_the_site_logo();
			return;
		}

		// Just display the site title
		$logo_html = '<h1 class="site-title">'.get_bloginfo( 'name' ).'</h1>';
		$logo_html = apply_filters('ultra_logo_text', $logo_html);
	}
	else {
		// Load the logo image
		if(is_array($logo)) {
			list ($src, $height, $width) = $logo;
		}
		else {
			$image = wp_get_attachment_image_src($logo, 'full');
			$src = $image[0];
			$height = $image[2];
			$width = $image[1];
		}

		// Add all the logo attributes
		$logo_attributes = apply_filters('ultra_logo_image_attributes', array(
			'src' => $src,
			'width' => round($width),
			'height' => round($height),
			'alt' => sprintf( __('%s Logo', 'ultra'), get_bloginfo('name') ),
			) );

		if( siteorigin_setting('header_sticky') && siteorigin_setting('header_scale') ) $logo_attributes['data-scale'] = '1';

		$logo_attributes_str = array();
		if( !empty( $logo_attributes ) ) {
			foreach($logo_attributes as $name => $val) {
				if( empty($val) ) continue;
				$logo_attributes_str[] = $name.'="'.esc_attr($val).'" ';
			}
		}


		$club_logo_file = get_stylesheet_directory() . "/assets/img/clubs-uofu-logo.png";
		if(file_exists($club_logo_file)){
			$club_logo_src = get_stylesheet_directory_uri() . "/assets/img/clubs-uofu-logo.png";
			$club_image = list($club_logo_width, $club_logo_height, $club_logo_type, $club_logo_attr) = getimagesize($club_logo_file);

			$club_logo_attributes = apply_filters('ultra_logo_image_attributes', array(
				'src' => $club_logo_src,
				'width' => round($club_logo_width),
				'height' => round($club_logo_height),
				'alt' => sprintf( __('%s Logo', 'ultra'), get_bloginfo('name') ),
				) );

			$club_logo_attributes_str = array();
			if( !empty( $club_logo_attributes ) ) {
				foreach($club_logo_attributes as $name => $val) {
					if( empty($val) ) continue;
					$club_logo_attributes_str[] = $name.'="'.esc_attr($val).'" ';
				}
			}

			$logo_html = apply_filters('ultra_logo_image', '<img '.implode( ' ', $logo_attributes_str ).' /><img '.implode( ' ', $club_logo_attributes_str ).' />');
		}
		else{
			$logo_html = apply_filters('ultra_logo_image', '<img '.implode( ' ', $logo_attributes_str ).' />');	
		}
	}

	// Echo the image
	echo apply_filters('ultra_logo_html', $logo_html);
}
endif;



include( get_stylesheet_directory() . '/inc/settings.php');


add_filter('upload_mimes', 'my_upload_mimes');

function my_upload_mimes ( $existing_mimes=array() ) {
    $existing_mimes['csv'] = 'text/csv';
    return $existing_mimes;
}


/** ACF Nav Menu **/

if(!function_exists('acf_site_header_sentinel')):
/**
 * Display the sticky header sentinel.
 */
function acf_site_header_sentinel(){
    ?>
    <header class="site-header site-header-sentinel<?php if( siteorigin_setting( 'header_scale' ) ) { echo ' scale'; } if( siteorigin_setting( 'navigation_responsive_menu' ) ) { echo ' responsive-menu'; } ?>" role="banner">
        <div class="container">
            <div class="site-branding-container">
                <div class="site-branding">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                        <?php ultra_display_logo(); ?>
                    </a>
                    <?php if( get_bloginfo('description') && siteorigin_setting('header_tagline') ) : ?>
                        <h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
                    <?php endif; ?>
                </div><!-- .site-branding -->
            </div><!-- .site-branding-container -->

            <nav class="main-navigation" role="navigation">
                <?php do_action('ultra_before_nav');
                    
                    if(function_exists('get_field')){ 
                        $custom_nav_menu = get_field('custom_nav_menu');
                        if(!empty($custom_nav_menu)){
                            echo $custom_nav_menu;
                        }
                        else{
                            wp_nav_menu( array( 'theme_location' => 'primary' ) ); 
                        }
                    }
                    else{
                        wp_nav_menu( array( 'theme_location' => 'primary' ) ); 
                    }

                ?>

                <?php if( siteorigin_setting('navigation_menu_search') ) : ?>
                    <div class="menu-search">
                        <div class="search-icon"></div>
                        <form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
                            <input type="text" class="field" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" />
                        </form> 
                    </div><!-- .menu-search -->
                <?php endif; ?>             
            </nav><!-- #site-navigation -->
        </div><!-- .container -->
    </header><!-- #masthead -->
    <?php
}
endif;



/**
 * Register extra widgetized areas.
 *
 */
function extended_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Sidebar', 'ultra' ),
        'id'            => 'sidebar-1',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'After Slider', 'ultra' ),
        'id'            => 'sidebar-after-slider',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );    

    register_sidebar( array(
        'name'          => __( 'Above Footer', 'ultra' ),
        'id'            => 'sidebar-above-footer',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer', 'ultra' ),
        'id'            => 'sidebar-2',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );    
}
add_action( 'widgets_init', 'extended_widgets_init' );



////
//  Only enable this when need be.
//// 

if(0){
    function custom_upload_zip($mimes) {
        $mimes = array_merge($mimes, array('zip' => 'application/zip'));
        return $mimes;
    }

    add_filter('upload_mimes', 'custom_upload_zip');
}



