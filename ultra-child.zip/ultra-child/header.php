<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ultra
 * @since ultra 0.9
 * @license GPL 2.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>

<!-- Custom CSS Includes -->
<?php
    if(function_exists('get_field')){ 

        $add_custom_css = get_field('add_custom_css');

        if($add_custom_css){
            $custom_css = get_field('custom_css');
            echo $custom_css;
        }                
    }
    
?>  


</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">
    <a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'ultra' ); ?></a>

    <?php if ( siteorigin_setting( 'header_top_bar' ) && siteorigin_page_setting( 'display_top_bar', true ) ) : ?>
        <?php get_template_part( 'parts/top-bar' ); ?>
    <?php endif; ?>

    <?php if ( siteorigin_setting( 'header_display' ) && siteorigin_page_setting( 'display_header', true ) ) : ?>
        <header id="masthead" class="site-header<?php if ( siteorigin_setting( 'header_sticky' ) ) echo ' sticky-header'; if ( siteorigin_setting( 'header_scale' ) ) echo ' scale'; if ( siteorigin_setting( 'navigation_responsive_menu' ) ) echo ' responsive-menu'; ?>">
            <div class="container">
                <div class="site-branding-container">
                    <div class="site-branding">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                            <?php ultra_display_logo(); ?>
                        </a>
                        <?php if ( get_bloginfo( 'description' ) && siteorigin_setting( 'header_tagline' ) ) : ?>
                            <h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
                        <?php endif; ?>
                    </div><!-- .site-branding -->
                </div><!-- .site-branding-container -->

                <nav id="site-navigation" class="main-navigation">
                    <?php do_action( 'ultra_before_nav' ); ?>
                    <?php if ( siteorigin_setting( 'navigation_primary_menu' ) ) //wp_nav_menu( array( 'theme_location' => 'primary' ) ); 
                        if(function_exists('get_field')){ 
                            $custom_nav_menu = get_field('custom_nav_menu');
                            if(!empty($custom_nav_menu)){
                                echo $custom_nav_menu;
                            }
                            else{
                                wp_nav_menu( array( 'theme_location' => 'primary' ) ); 
                            }
                        }
                        else{
                            wp_nav_menu( array( 'theme_location' => 'primary' ) ); 
                        }

                    ?>
                    <?php if ( siteorigin_setting( 'navigation_menu_search' ) ) : ?>
                        <div class="menu-search">
                            <div class="search-icon"></div>
                            <form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                                <input type="text" class="field" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" />
                            </form> 
                        </div><!-- .menu-search -->
                    <?php endif; ?>
                </nav><!-- #site-navigation -->
            </div><!-- .container -->
        </header><!-- #masthead -->
    <?php endif; ?>


    <?php
        if(function_exists('get_field')){ 

            $use_crelly_slider = get_field('use_crelly_slider');
            $use_rev_slider = get_field('use_rev_slider');
            if($use_rev_slider){
                $slider_alias = get_field('rev_slider_alias');
                if(function_exists("putRevSlider") && $slider_alias){
                    putRevSlider("$slider_alias");
                }
            }            
            else if($use_crelly_slider){
                $slider_alias = get_field('crelly_slider_alias');
                if(function_exists("crellySlider") && $slider_alias){
                    crellySlider("$slider_alias");
                }
            }
            else{
                ultra_render_slider();
            }   
        }
        else{
            ultra_render_slider();
        }
    ?>

    <?php  
    ////
    //  Sub Page Header  -- If supplied by Custom Page Header in advanced custom field
    ////
    if(function_exists('get_field')){
        $use_custom_page_header = get_field('use_custom_page_header');
        if($use_custom_page_header){
            $custom_page_header_image = get_field('header_image');
            if(!empty($custom_page_header_image)){
            ?>
        <div id="custom-header-image-container" class="">
            <img id="custom-header-image" src="<?= $custom_page_header_image;?>" />        
        </div>


            <?php
            }
        }            
    }

    ?>    


    <div id="content" class="site-content">

        <?php if ( class_exists( 'WooCommerce' ) && is_woocommerce() ) get_template_part( 'parts/woocommerce-title' ); ?>
