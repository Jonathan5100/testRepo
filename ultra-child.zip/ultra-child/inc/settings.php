<?php





// /**
//  * Initialize the settings.
//  */
// function ultra_settings_extra_init(){

// 	// Header
// 	siteorigin_settings_add_field('header', 'matt_test', 'media', __('MattTest', 'ultra'), array(
// 		'description' => __('Your own custom test.', 'ultra')
// 	) );

// 	siteorigin_settings_add_field('social', 'facebook', 'text', __('Facebook', 'ultra'), array(
// 		'description' => __('Facebook Url.', 'ultra')
// 	) );
// 	siteorigin_settings_add_field('social', 'instagram', 'text', __('Instagram', 'ultra'), array(
// 		'description' => __('Instagram Url.', 'ultra')
// 	) );
// 	siteorigin_settings_add_field('social', 'twitter', 'text', __('Twitter', 'ultra'), array(
// 		'description' => __('Twitter Url.', 'ultra')
// 	) );


// }
// add_action('siteorigin_settings_init', 'ultra_settings_extra_init');

// /**
//  * Add default settings.
//  *
//  * @param $defaults
//  *
//  * @return mixed
//  */
// function ultra_settings_new_defaults( $defaults ){
// 	$defaults['header_matt_test'] = false;
// 	$defaults['social_facebook'] = '';	
// 	$defaults['social_instagram'] = '';	
// 	$defaults['social_twitter'] = '';	
// 	return $defaults;
// }
// add_filter('siteorigin_theme_default_settings', 'ultra_settings_defaults');

?>