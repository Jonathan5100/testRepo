<?php
/**
 * Template Name: Posts & Past Events Listing V2
 *
 * @package ultra
 * @since ultra 0.9
 * @license GPL 2.0
 */
get_header(); 


?>
    <div class="container">
        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">
<h1 style=""> Past Events </h1>       
                <div class="row">
              <div class="col-xs-12 col-sm-12 grid">
                  

          
<?php

////
//  Category
////
// Retrieve any upcoming events starting January 1st, 2015, or later
if(function_exists('tribe_get_events')){
    $events = tribe_get_events( array(
        'eventDisplay' => 'custom',
        'end_date'   => date('Y-m-d', time())
    ) );

    usort($events, function($a, $b){
        return  mktime($b->EventStartDate) <=> mktime($a->EventStartDate);
    });

    foreach($events as $event){
    $link = extractThumbnailFromEvent($event);
    $link = is_null($link) ? '' : $link;
    echo <<<EOT
    <article  class="post type-post status-publish format-standard hentry category-event grid-item">
            <div class="entry-content">
                <p>
                    <a rel="shortlink" href="{$event->guid}" title="{$event->post_title}">
                        <div class="event-item" style="position:relative; width:180px; height:135px; ">    
                            $link
                            <div class="event-overlay" style="width: 180px; height: 100%; position:absolute; bottom: 0px; left:0px; background-color:rgba(0,0,0,.4); display:table; text-align:center; padding:5px;">
                                <span style="display:table-cell; vertical-align:middle; font-size: 18px; font-weight:600; color: #fff;"> {$event->post_title} </span>
                            </div> 
                        </div>                            
                    </a>            
                </p>
            </div>

    <footer class="entry-footer">
                    </footer><!-- .entry-footer -->            
        </article>

EOT;

    }
}

    
?>


                    </div> <!-- END 1nd Col Past Calendar Events -->
                </div> <!-- END Row -->
<script src="https://admin.coe.utah.edu/public/assets/vendor/masonry/masonry.pkgd.min.js"></script>
<script type="text/javascript">
(function($) {
    $(document).ready(function(){
        $('.event-item').each(function(key, value){        
            var img = $(value).find('img').first();
            // make sure it sits in the middle
            if(img){
                img.css('display', 'block');        
                var img_height = img.height();
                var height = $(value).height();
                var img_margin = (height - img_height) / 2;
                img.css('margin-top', '0px');
                img.css('height', 'auto');
                img.css('padding-top', img_margin);
            }
            else{
                var height = $(value).height();                
            }
            
            $(value).find('.event-overlay').css('height', height);
        });

        $('.event-item .event-overlay').on('mouseenter', function(){
            var old_rgb = $(this).css('background-color'); //rgb(100,100,100),
            var new_rgba = old_rgb.replace(/([^,]+)(?=\))/, "0.8"); //rgba(100,100,100,.8);         
            console.log(old_rgb);
            console.log(new_rgba);
            $(this).css('background-color', new_rgba);
        });

        $('.event-item .event-overlay').on('mouseleave', function(){
            var old_rgb = $(this).css('background-color'); //rgb(100,100,100),
            var new_rgba = old_rgb.replace(/([^,]+)(?=\))/, "0.4"); //rgba(100,100,100,.8);
            console.log(old_rgb);
            console.log(new_rgba);            
            $(this).css('background-color', new_rgba);
        });
    });

    $('.grid').masonry({
      // options
      itemSelector: '.grid-item',
      columnWidth: 200
    });

})( jQuery );    
</script>


            </main><!-- #main -->
        </div><!-- #primary -->

        <?php get_sidebar(); ?>

<?php get_footer(); ?>


<?php 

function extractThumbnailFromEvent($event){
    //get photogallery id if it exists
    $id = preg_replace('/\[Best_Wordpress_Gallery id="([0-9]+)".*/', "$1", preg_replace('/\s+/', ' ',$event->post_content));
    if(!is_numeric($id)){
        return null;
    }

    
    if(function_exists('photo_gallery')){

        ob_start();
        photo_gallery($id);
        $pg = ob_get_contents();        
        ob_end_clean();

    }
    
    try{    
        $doc = new DOMDocument();
        $doc->loadHTML($pg);
        $image_html = $doc->saveXML($doc->getElementsByTagName('img')->item(0));
    }
    catch(Exception $e){
        //noop
    }

    return $image_html;
    

}


 ?>
