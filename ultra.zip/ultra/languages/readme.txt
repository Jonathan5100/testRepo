Please visit the following links to learn more about translating WordPress themes:

https://codex.wordpress.org/WordPress_in_Your_Language
https://make.wordpress.org/docs/theme-developer-handbook/part-two-theme-functionality/localization/
https://codex.wordpress.org/Function_Reference/load_theme_textdomain
